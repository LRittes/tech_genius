package com.example.otes06.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;


import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.example.otes06.R;

public class QuizActivity extends AppCompatActivity {
    private TextView questionTextView;
    private RadioGroup optionsRadioGroup;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // Obtém as referências dos elementos da tela
        questionTextView = findViewById(R.id.questionTextView);
        optionsRadioGroup = findViewById(R.id.optionsRadioGroup);
        submitButton = findViewById(R.id.submitButton);

        // Define a pergunta e as alternativas de resposta
        String question = "Qual é a capital do Brasil?";
        String[] options = {"Rio de Janeiro", "São Paulo", "Brasília", "Salvador"};

        // Define a pergunta na TextView
        questionTextView.setText(question);


        // Define o ouvinte de clique para o botão de envio
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtém o índice da alternativa selecionada
                int selectedOptionIndex = optionsRadioGroup.getCheckedRadioButtonId();

                if (selectedOptionIndex == -1) {
                    // Nenhuma alternativa selecionada
                    Toast.makeText(QuizActivity.this, "Selecione uma alternativa", Toast.LENGTH_SHORT).show();
                } else {
                    // Alternativa selecionada
                    RadioButton selectedOptionRadioButton = findViewById(selectedOptionIndex);
                    String selectedOption = selectedOptionRadioButton.getText().toString();

                    // Realiza a verificação da resposta
                    if (selectedOption.equals("Brasília")) {
                        Toast.makeText(QuizActivity.this, "Resposta correta!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(QuizActivity.this, "Resposta incorreta!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}