package com.example.otes06.controllers;

import com.example.otes06.models.User;

public class GameController {
    public User createUser() {
        return new User();
    }
}
